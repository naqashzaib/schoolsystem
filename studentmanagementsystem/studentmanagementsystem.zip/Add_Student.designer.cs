﻿namespace studentmanagementsystem
{
    partial class Add_Student
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Add_Student));
            this.label9 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txts_note = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txts_mobile_phone = new System.Windows.Forms.MaskedTextBox();
            this.txtsgender = new System.Windows.Forms.ComboBox();
            this.txtsfnam = new System.Windows.Forms.TextBox();
            this.txtsname = new System.Windows.Forms.TextBox();
            this.edit7 = new MetroFramework.Controls.MetroTile();
            this.edit3 = new MetroFramework.Controls.MetroTile();
            this.edit2 = new MetroFramework.Controls.MetroTile();
            this.edit1 = new MetroFramework.Controls.MetroTile();
            this.edit11 = new MetroFramework.Controls.MetroTile();
            this.btndeleteteac = new MetroFramework.Controls.MetroButton();
            this.btnupdateteac = new MetroFramework.Controls.MetroButton();
            this.txtsinsert = new MetroFramework.Controls.MetroButton();
            this.label15 = new System.Windows.Forms.Label();
            this.edit8 = new MetroFramework.Controls.MetroTile();
            this.label8 = new System.Windows.Forms.Label();
            this.txtsdob = new System.Windows.Forms.MaskedTextBox();
            this.change_spic = new MetroFramework.Controls.MetroButton();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.refreshbtn = new MetroFramework.Controls.MetroButton();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.txtsearchstudent = new System.Windows.Forms.MaskedTextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.edit12 = new MetroFramework.Controls.MetroTile();
            this.stueditrollnumber = new MetroFramework.Controls.MetroTile();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.rollnos = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.time = new System.Windows.Forms.Label();
            this.editstatusstudent = new MetroFramework.Controls.MetroTile();
            this.label17 = new System.Windows.Forms.Label();
            this.txtstatus = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txts_email = new System.Windows.Forms.TextBox();
            this.metroTile2 = new MetroFramework.Controls.MetroTile();
            this.label20 = new System.Windows.Forms.Label();
            this.txts_home_phone = new System.Windows.Forms.MaskedTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txts_street = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txts_city = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txts_zip_code = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txts_country = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.team_id = new System.Windows.Forms.ComboBox();
            this.txts_ready_password = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.metroTile3 = new MetroFramework.Controls.MetroTile();
            this.metroTile4 = new MetroFramework.Controls.MetroTile();
            this.metroTile5 = new MetroFramework.Controls.MetroTile();
            this.metroTile6 = new MetroFramework.Controls.MetroTile();
            this.metroTile7 = new MetroFramework.Controls.MetroTile();
            this.metroTile8 = new MetroFramework.Controls.MetroTile();
            this.txts_start_date = new System.Windows.Forms.DateTimePicker();
            this.txtbarcode = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txts_id = new System.Windows.Forms.TextBox();
            this.metroTile1 = new MetroFramework.Controls.MetroTile();
            this.edit10 = new MetroFramework.Controls.MetroTile();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(132, 209);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(72, 19);
            this.label9.TabIndex = 154;
            this.label9.Text = "Roll # :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(114, 469);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(63, 19);
            this.label14.TabIndex = 144;
            this.label14.Text = "Note :";
            // 
            // txts_note
            // 
            this.txts_note.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txts_note.Location = new System.Drawing.Point(209, 469);
            this.txts_note.Name = "txts_note";
            this.txts_note.Size = new System.Drawing.Size(537, 29);
            this.txts_note.TabIndex = 11;
            this.txts_note.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtsaddres_KeyPress);
            this.txts_note.Leave += new System.EventHandler(this.txtsaddres_Leave);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(509, 301);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 19);
            this.label7.TabIndex = 141;
            this.label7.Text = "Team :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(489, 340);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 19);
            this.label6.TabIndex = 140;
            this.label6.Text = "Mobile  # :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(121, 314);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 19);
            this.label4.TabIndex = 138;
            this.label4.Text = "Gender :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(73, 279);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(131, 19);
            this.label3.TabIndex = 137;
            this.label3.Text = "Father Name :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(89, 244);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 19);
            this.label2.TabIndex = 136;
            this.label2.Text = "First Name :";
            // 
            // txts_mobile_phone
            // 
            this.txts_mobile_phone.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txts_mobile_phone.Location = new System.Drawing.Point(600, 335);
            this.txts_mobile_phone.Name = "txts_mobile_phone";
            this.txts_mobile_phone.Size = new System.Drawing.Size(183, 29);
            this.txts_mobile_phone.TabIndex = 9;
            this.txts_mobile_phone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtscntct_KeyPress);
            this.txts_mobile_phone.Leave += new System.EventHandler(this.txtscntct_Leave);
            // 
            // txtsgender
            // 
            this.txtsgender.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsgender.FormattingEnabled = true;
            this.txtsgender.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.txtsgender.Location = new System.Drawing.Point(210, 314);
            this.txtsgender.Name = "txtsgender";
            this.txtsgender.Size = new System.Drawing.Size(234, 32);
            this.txtsgender.TabIndex = 3;
            this.txtsgender.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtsgender_KeyPress);
            this.txtsgender.Leave += new System.EventHandler(this.txtsgender_Leave);
            // 
            // txtsfnam
            // 
            this.txtsfnam.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsfnam.Location = new System.Drawing.Point(210, 279);
            this.txtsfnam.Name = "txtsfnam";
            this.txtsfnam.Size = new System.Drawing.Size(234, 29);
            this.txtsfnam.TabIndex = 2;
            this.txtsfnam.TextChanged += new System.EventHandler(this.txtsfnam_TextChanged);
            this.txtsfnam.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtsfnam_KeyPress);
            this.txtsfnam.Leave += new System.EventHandler(this.txtsfnam_Leave);
            // 
            // txtsname
            // 
            this.txtsname.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsname.Location = new System.Drawing.Point(210, 244);
            this.txtsname.Name = "txtsname";
            this.txtsname.Size = new System.Drawing.Size(234, 29);
            this.txtsname.TabIndex = 1;
            this.txtsname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtsname_KeyPress);
            this.txtsname.Leave += new System.EventHandler(this.txtsname_Leave);
            // 
            // edit7
            // 
            this.edit7.ActiveControl = null;
            this.edit7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.edit7.Location = new System.Drawing.Point(752, 469);
            this.edit7.Name = "edit7";
            this.edit7.Size = new System.Drawing.Size(15, 14);
            this.edit7.TabIndex = 151;
            this.edit7.TileImage = ((System.Drawing.Image)(resources.GetObject("edit7.TileImage")));
            this.edit7.UseCustomBackColor = true;
            this.edit7.UseCustomForeColor = true;
            this.edit7.UseSelectable = true;
            this.edit7.UseStyleColors = true;
            this.edit7.UseTileImage = true;
            this.edit7.Click += new System.EventHandler(this.edit7_Click);
            // 
            // edit3
            // 
            this.edit3.ActiveControl = null;
            this.edit3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.edit3.Location = new System.Drawing.Point(450, 316);
            this.edit3.Name = "edit3";
            this.edit3.Size = new System.Drawing.Size(15, 14);
            this.edit3.TabIndex = 147;
            this.edit3.TileImage = ((System.Drawing.Image)(resources.GetObject("edit3.TileImage")));
            this.edit3.UseCustomBackColor = true;
            this.edit3.UseCustomForeColor = true;
            this.edit3.UseSelectable = true;
            this.edit3.UseStyleColors = true;
            this.edit3.UseTileImage = true;
            this.edit3.Click += new System.EventHandler(this.edit3_Click);
            // 
            // edit2
            // 
            this.edit2.ActiveControl = null;
            this.edit2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.edit2.Location = new System.Drawing.Point(450, 284);
            this.edit2.Name = "edit2";
            this.edit2.Size = new System.Drawing.Size(15, 14);
            this.edit2.TabIndex = 146;
            this.edit2.TileImage = ((System.Drawing.Image)(resources.GetObject("edit2.TileImage")));
            this.edit2.UseCustomBackColor = true;
            this.edit2.UseCustomForeColor = true;
            this.edit2.UseSelectable = true;
            this.edit2.UseStyleColors = true;
            this.edit2.UseTileImage = true;
            this.edit2.Click += new System.EventHandler(this.edit2_Click);
            // 
            // edit1
            // 
            this.edit1.ActiveControl = null;
            this.edit1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.edit1.Location = new System.Drawing.Point(450, 249);
            this.edit1.Name = "edit1";
            this.edit1.Size = new System.Drawing.Size(15, 14);
            this.edit1.TabIndex = 145;
            this.edit1.TileImage = ((System.Drawing.Image)(resources.GetObject("edit1.TileImage")));
            this.edit1.UseCustomBackColor = true;
            this.edit1.UseCustomForeColor = true;
            this.edit1.UseSelectable = true;
            this.edit1.UseStyleColors = true;
            this.edit1.UseTileImage = true;
            this.edit1.Click += new System.EventHandler(this.edit1_Click);
            // 
            // edit11
            // 
            this.edit11.ActiveControl = null;
            this.edit11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.edit11.Location = new System.Drawing.Point(789, 332);
            this.edit11.Name = "edit11";
            this.edit11.Size = new System.Drawing.Size(15, 14);
            this.edit11.TabIndex = 165;
            this.edit11.TileImage = ((System.Drawing.Image)(resources.GetObject("edit11.TileImage")));
            this.edit11.UseCustomBackColor = true;
            this.edit11.UseCustomForeColor = true;
            this.edit11.UseSelectable = true;
            this.edit11.UseStyleColors = true;
            this.edit11.UseTileImage = true;
            this.edit11.Click += new System.EventHandler(this.edit11_Click);
            // 
            // btndeleteteac
            // 
            this.btndeleteteac.BackColor = System.Drawing.Color.IndianRed;
            this.btndeleteteac.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btndeleteteac.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.btndeleteteac.ForeColor = System.Drawing.Color.White;
            this.btndeleteteac.Location = new System.Drawing.Point(550, 561);
            this.btndeleteteac.Name = "btndeleteteac";
            this.btndeleteteac.Size = new System.Drawing.Size(154, 36);
            this.btndeleteteac.TabIndex = 168;
            this.btndeleteteac.Text = "Delete";
            this.btndeleteteac.UseCustomBackColor = true;
            this.btndeleteteac.UseCustomForeColor = true;
            this.btndeleteteac.UseSelectable = true;
            this.btndeleteteac.UseStyleColors = true;
            this.btndeleteteac.Click += new System.EventHandler(this.btndeleteteac_Click);
            // 
            // btnupdateteac
            // 
            this.btnupdateteac.BackColor = System.Drawing.Color.Gold;
            this.btnupdateteac.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnupdateteac.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.btnupdateteac.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnupdateteac.Location = new System.Drawing.Point(379, 561);
            this.btnupdateteac.Name = "btnupdateteac";
            this.btnupdateteac.Size = new System.Drawing.Size(154, 36);
            this.btnupdateteac.TabIndex = 167;
            this.btnupdateteac.Text = "Update";
            this.btnupdateteac.UseCustomBackColor = true;
            this.btnupdateteac.UseCustomForeColor = true;
            this.btnupdateteac.UseSelectable = true;
            this.btnupdateteac.UseStyleColors = true;
            this.btnupdateteac.Click += new System.EventHandler(this.btnupdateteac_Click);
            // 
            // txtsinsert
            // 
            this.txtsinsert.BackColor = System.Drawing.Color.Teal;
            this.txtsinsert.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtsinsert.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.txtsinsert.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtsinsert.Location = new System.Drawing.Point(208, 561);
            this.txtsinsert.Name = "txtsinsert";
            this.txtsinsert.Size = new System.Drawing.Size(154, 36);
            this.txtsinsert.TabIndex = 12;
            this.txtsinsert.Text = "Save";
            this.txtsinsert.UseCustomBackColor = true;
            this.txtsinsert.UseCustomForeColor = true;
            this.txtsinsert.UseSelectable = true;
            this.txtsinsert.UseStyleColors = true;
            this.txtsinsert.Click += new System.EventHandler(this.txtinsert_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Forte", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.SlateGray;
            this.label15.Location = new System.Drawing.Point(543, 71);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(322, 44);
            this.label15.TabIndex = 169;
            this.label15.Text = "ADD_STUDENTS";
            // 
            // edit8
            // 
            this.edit8.ActiveControl = null;
            this.edit8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.edit8.Location = new System.Drawing.Point(789, 209);
            this.edit8.Name = "edit8";
            this.edit8.Size = new System.Drawing.Size(15, 14);
            this.edit8.TabIndex = 172;
            this.edit8.TileImage = ((System.Drawing.Image)(resources.GetObject("edit8.TileImage")));
            this.edit8.UseCustomBackColor = true;
            this.edit8.UseCustomForeColor = true;
            this.edit8.UseSelectable = true;
            this.edit8.UseStyleColors = true;
            this.edit8.UseTileImage = true;
            this.edit8.Click += new System.EventHandler(this.edit8_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(535, 219);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 19);
            this.label8.TabIndex = 171;
            this.label8.Text = "DOB :";
            // 
            // txtsdob
            // 
            this.txtsdob.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsdob.Location = new System.Drawing.Point(599, 212);
            this.txtsdob.Mask = "99-99-9999";
            this.txtsdob.Name = "txtsdob";
            this.txtsdob.Size = new System.Drawing.Size(184, 29);
            this.txtsdob.TabIndex = 6;
            this.txtsdob.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtsdob_KeyPress);
            this.txtsdob.Leave += new System.EventHandler(this.txtsdob_Leave);
            // 
            // change_spic
            // 
            this.change_spic.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.change_spic.Cursor = System.Windows.Forms.Cursors.Hand;
            this.change_spic.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.change_spic.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.change_spic.Location = new System.Drawing.Point(820, 365);
            this.change_spic.Name = "change_spic";
            this.change_spic.Size = new System.Drawing.Size(162, 23);
            this.change_spic.TabIndex = 174;
            this.change_spic.Text = "Chang Pic";
            this.change_spic.UseCustomBackColor = true;
            this.change_spic.UseCustomForeColor = true;
            this.change_spic.UseSelectable = true;
            this.change_spic.UseStyleColors = true;
            this.change_spic.Click += new System.EventHandler(this.schange_spic_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.White;
            this.pictureBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox3.Image = global::studentmanagementsystem.Properties.Resources._13_512;
            this.pictureBox3.Location = new System.Drawing.Point(820, 212);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(162, 147);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 173;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // refreshbtn
            // 
            this.refreshbtn.BackColor = System.Drawing.Color.Transparent;
            this.refreshbtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("refreshbtn.BackgroundImage")));
            this.refreshbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.refreshbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.refreshbtn.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.refreshbtn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.refreshbtn.Location = new System.Drawing.Point(1222, 166);
            this.refreshbtn.Name = "refreshbtn";
            this.refreshbtn.Size = new System.Drawing.Size(47, 37);
            this.refreshbtn.TabIndex = 176;
            this.refreshbtn.UseCustomBackColor = true;
            this.refreshbtn.UseCustomForeColor = true;
            this.refreshbtn.UseSelectable = true;
            this.refreshbtn.UseStyleColors = true;
            this.refreshbtn.Click += new System.EventHandler(this.refreshbtn_Click);
            // 
            // metroPanel1
            // 
            this.metroPanel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.metroPanel1.Controls.Add(this.txtsearchstudent);
            this.metroPanel1.Controls.Add(this.pictureBox2);
            this.metroPanel1.Controls.Add(this.label10);
            this.metroPanel1.Controls.Add(this.label12);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(1013, 239);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(285, 125);
            this.metroPanel1.TabIndex = 175;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // txtsearchstudent
            // 
            this.txtsearchstudent.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsearchstudent.Location = new System.Drawing.Point(71, 65);
            this.txtsearchstudent.Name = "txtsearchstudent";
            this.txtsearchstudent.Size = new System.Drawing.Size(184, 29);
            this.txtsearchstudent.TabIndex = 85;
            this.txtsearchstudent.TextChanged += new System.EventHandler(this.txtsearchstudent_TextChanged);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::studentmanagementsystem.Properties.Resources.search_icon;
            this.pictureBox2.Location = new System.Drawing.Point(21, 15);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(31, 26);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 84;
            this.pictureBox2.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(58, 15);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(201, 19);
            this.label10.TabIndex = 56;
            this.label10.Text = "Student\'s Search Panel";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(3, 71);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(66, 19);
            this.label12.TabIndex = 55;
            this.label12.Text = "Roll #:";
            // 
            // edit12
            // 
            this.edit12.ActiveControl = null;
            this.edit12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.edit12.Location = new System.Drawing.Point(988, 209);
            this.edit12.Name = "edit12";
            this.edit12.Size = new System.Drawing.Size(15, 14);
            this.edit12.TabIndex = 178;
            this.edit12.TileImage = ((System.Drawing.Image)(resources.GetObject("edit12.TileImage")));
            this.edit12.UseCustomBackColor = true;
            this.edit12.UseCustomForeColor = true;
            this.edit12.UseSelectable = true;
            this.edit12.UseStyleColors = true;
            this.edit12.UseTileImage = true;
            this.edit12.Click += new System.EventHandler(this.edit12_Click);
            // 
            // stueditrollnumber
            // 
            this.stueditrollnumber.ActiveControl = null;
            this.stueditrollnumber.Cursor = System.Windows.Forms.Cursors.Hand;
            this.stueditrollnumber.Location = new System.Drawing.Point(450, 209);
            this.stueditrollnumber.Name = "stueditrollnumber";
            this.stueditrollnumber.Size = new System.Drawing.Size(15, 14);
            this.stueditrollnumber.TabIndex = 181;
            this.stueditrollnumber.TileImage = ((System.Drawing.Image)(resources.GetObject("stueditrollnumber.TileImage")));
            this.stueditrollnumber.UseCustomBackColor = true;
            this.stueditrollnumber.UseCustomForeColor = true;
            this.stueditrollnumber.UseSelectable = true;
            this.stueditrollnumber.UseStyleColors = true;
            this.stueditrollnumber.UseTileImage = true;
            this.stueditrollnumber.Click += new System.EventHandler(this.edit0_Click);
            // 
            // timer2
            // 
            this.timer2.Interval = 1000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // rollnos
            // 
            this.rollnos.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rollnos.Location = new System.Drawing.Point(208, 209);
            this.rollnos.Name = "rollnos";
            this.rollnos.Size = new System.Drawing.Size(234, 29);
            this.rollnos.TabIndex = 184;
            this.rollnos.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(224, 81);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(138, 87);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 177;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::studentmanagementsystem.Properties.Resources.ssu_school_logo;
            this.pictureBox4.Location = new System.Drawing.Point(23, 17);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(173, 62);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 185;
            this.pictureBox4.TabStop = false;
            // 
            // time
            // 
            this.time.AutoSize = true;
            this.time.Font = new System.Drawing.Font("DS-Digital", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.time.ForeColor = System.Drawing.Color.Crimson;
            this.time.Location = new System.Drawing.Point(1132, 71);
            this.time.Name = "time";
            this.time.Size = new System.Drawing.Size(124, 31);
            this.time.TabIndex = 186;
            this.time.Text = "00:00:00";
            this.time.Click += new System.EventHandler(this.time_Click);
            // 
            // editstatusstudent
            // 
            this.editstatusstudent.ActiveControl = null;
            this.editstatusstudent.Cursor = System.Windows.Forms.Cursors.Hand;
            this.editstatusstudent.Location = new System.Drawing.Point(788, 174);
            this.editstatusstudent.Name = "editstatusstudent";
            this.editstatusstudent.Size = new System.Drawing.Size(15, 14);
            this.editstatusstudent.TabIndex = 193;
            this.editstatusstudent.TileImage = ((System.Drawing.Image)(resources.GetObject("editstatusstudent.TileImage")));
            this.editstatusstudent.UseCustomBackColor = true;
            this.editstatusstudent.UseCustomForeColor = true;
            this.editstatusstudent.UseSelectable = true;
            this.editstatusstudent.UseStyleColors = true;
            this.editstatusstudent.UseTileImage = true;
            this.editstatusstudent.Click += new System.EventHandler(this.editstatusstudent_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(516, 174);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(77, 19);
            this.label17.TabIndex = 191;
            this.label17.Text = "Status :";
            // 
            // txtstatus
            // 
            this.txtstatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstatus.FormattingEnabled = true;
            this.txtstatus.Items.AddRange(new object[] {
            "Active",
            "Leave"});
            this.txtstatus.Location = new System.Drawing.Point(599, 166);
            this.txtstatus.Name = "txtstatus";
            this.txtstatus.Size = new System.Drawing.Size(183, 32);
            this.txtstatus.TabIndex = 194;
            this.txtstatus.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtstatus_KeyPress_1);
            this.txtstatus.Leave += new System.EventHandler(this.txtstatus_Leave);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(106, 358);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(97, 19);
            this.label19.TabIndex = 201;
            this.label19.Text = "E-mail Id :";
            // 
            // txts_email
            // 
            this.txts_email.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txts_email.Location = new System.Drawing.Point(209, 352);
            this.txts_email.Name = "txts_email";
            this.txts_email.Size = new System.Drawing.Size(235, 29);
            this.txts_email.TabIndex = 200;
            // 
            // metroTile2
            // 
            this.metroTile2.ActiveControl = null;
            this.metroTile2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroTile2.Location = new System.Drawing.Point(450, 350);
            this.metroTile2.Name = "metroTile2";
            this.metroTile2.Size = new System.Drawing.Size(15, 14);
            this.metroTile2.TabIndex = 205;
            this.metroTile2.TileImage = ((System.Drawing.Image)(resources.GetObject("metroTile2.TileImage")));
            this.metroTile2.UseCustomBackColor = true;
            this.metroTile2.UseCustomForeColor = true;
            this.metroTile2.UseSelectable = true;
            this.metroTile2.UseStyleColors = true;
            this.metroTile2.UseTileImage = true;
            this.metroTile2.Click += new System.EventHandler(this.metroTile2_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(107, 394);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(97, 19);
            this.label20.TabIndex = 204;
            this.label20.Text = "Home  # :";
            // 
            // txts_home_phone
            // 
            this.txts_home_phone.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txts_home_phone.Location = new System.Drawing.Point(210, 387);
            this.txts_home_phone.Name = "txts_home_phone";
            this.txts_home_phone.Size = new System.Drawing.Size(234, 29);
            this.txts_home_phone.TabIndex = 203;
            this.txts_home_phone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txts_home_phone_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(114, 434);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 19);
            this.label1.TabIndex = 207;
            this.label1.Text = "Street";
            // 
            // txts_street
            // 
            this.txts_street.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txts_street.Location = new System.Drawing.Point(209, 434);
            this.txts_street.Name = "txts_street";
            this.txts_street.Size = new System.Drawing.Size(72, 29);
            this.txts_street.TabIndex = 206;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(342, 441);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 19);
            this.label5.TabIndex = 210;
            this.label5.Text = "City";
            // 
            // txts_city
            // 
            this.txts_city.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txts_city.Location = new System.Drawing.Point(390, 434);
            this.txts_city.Name = "txts_city";
            this.txts_city.Size = new System.Drawing.Size(72, 29);
            this.txts_city.TabIndex = 209;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(503, 431);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(83, 19);
            this.label11.TabIndex = 212;
            this.label11.Text = "Zip Code";
            // 
            // txts_zip_code
            // 
            this.txts_zip_code.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txts_zip_code.Location = new System.Drawing.Point(592, 427);
            this.txts_zip_code.Name = "txts_zip_code";
            this.txts_zip_code.Size = new System.Drawing.Size(72, 29);
            this.txts_zip_code.TabIndex = 211;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(684, 427);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(76, 19);
            this.label13.TabIndex = 214;
            this.label13.Text = "Country";
            // 
            // txts_country
            // 
            this.txts_country.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txts_country.Location = new System.Drawing.Point(773, 423);
            this.txts_country.Name = "txts_country";
            this.txts_country.Size = new System.Drawing.Size(72, 29);
            this.txts_country.TabIndex = 213;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(490, 259);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(104, 19);
            this.label18.TabIndex = 215;
            this.label18.Text = "Start Date:";
            // 
            // team_id
            // 
            this.team_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.team_id.FormattingEnabled = true;
            this.team_id.Items.AddRange(new object[] {
            "Select Team"});
            this.team_id.Location = new System.Drawing.Point(600, 294);
            this.team_id.Name = "team_id";
            this.team_id.Size = new System.Drawing.Size(183, 32);
            this.team_id.TabIndex = 8;
            this.team_id.Leave += new System.EventHandler(this.txtssection_Leave);
            // 
            // txts_ready_password
            // 
            this.txts_ready_password.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txts_ready_password.Location = new System.Drawing.Point(210, 504);
            this.txts_ready_password.Name = "txts_ready_password";
            this.txts_ready_password.Size = new System.Drawing.Size(183, 29);
            this.txts_ready_password.TabIndex = 220;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(56, 511);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(160, 19);
            this.label21.TabIndex = 219;
            this.label21.Text = "Ready Password :";
            // 
            // metroTile3
            // 
            this.metroTile3.ActiveControl = null;
            this.metroTile3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroTile3.Location = new System.Drawing.Point(450, 387);
            this.metroTile3.Name = "metroTile3";
            this.metroTile3.Size = new System.Drawing.Size(15, 14);
            this.metroTile3.TabIndex = 222;
            this.metroTile3.TileImage = ((System.Drawing.Image)(resources.GetObject("metroTile3.TileImage")));
            this.metroTile3.UseCustomBackColor = true;
            this.metroTile3.UseCustomForeColor = true;
            this.metroTile3.UseSelectable = true;
            this.metroTile3.UseStyleColors = true;
            this.metroTile3.UseTileImage = true;
            this.metroTile3.Click += new System.EventHandler(this.metroTile3_Click);
            // 
            // metroTile4
            // 
            this.metroTile4.ActiveControl = null;
            this.metroTile4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroTile4.Location = new System.Drawing.Point(287, 436);
            this.metroTile4.Name = "metroTile4";
            this.metroTile4.Size = new System.Drawing.Size(15, 14);
            this.metroTile4.TabIndex = 223;
            this.metroTile4.TileImage = ((System.Drawing.Image)(resources.GetObject("metroTile4.TileImage")));
            this.metroTile4.UseCustomBackColor = true;
            this.metroTile4.UseCustomForeColor = true;
            this.metroTile4.UseSelectable = true;
            this.metroTile4.UseStyleColors = true;
            this.metroTile4.UseTileImage = true;
            this.metroTile4.Click += new System.EventHandler(this.metroTile4_Click);
            // 
            // metroTile5
            // 
            this.metroTile5.ActiveControl = null;
            this.metroTile5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroTile5.Location = new System.Drawing.Point(468, 434);
            this.metroTile5.Name = "metroTile5";
            this.metroTile5.Size = new System.Drawing.Size(15, 14);
            this.metroTile5.TabIndex = 224;
            this.metroTile5.TileImage = ((System.Drawing.Image)(resources.GetObject("metroTile5.TileImage")));
            this.metroTile5.UseCustomBackColor = true;
            this.metroTile5.UseCustomForeColor = true;
            this.metroTile5.UseSelectable = true;
            this.metroTile5.UseStyleColors = true;
            this.metroTile5.UseTileImage = true;
            this.metroTile5.Click += new System.EventHandler(this.metroTile5_Click);
            // 
            // metroTile6
            // 
            this.metroTile6.ActiveControl = null;
            this.metroTile6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroTile6.Location = new System.Drawing.Point(670, 427);
            this.metroTile6.Name = "metroTile6";
            this.metroTile6.Size = new System.Drawing.Size(15, 14);
            this.metroTile6.TabIndex = 225;
            this.metroTile6.TileImage = ((System.Drawing.Image)(resources.GetObject("metroTile6.TileImage")));
            this.metroTile6.UseCustomBackColor = true;
            this.metroTile6.UseCustomForeColor = true;
            this.metroTile6.UseSelectable = true;
            this.metroTile6.UseStyleColors = true;
            this.metroTile6.UseTileImage = true;
            this.metroTile6.Click += new System.EventHandler(this.metroTile6_Click);
            // 
            // metroTile7
            // 
            this.metroTile7.ActiveControl = null;
            this.metroTile7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroTile7.Location = new System.Drawing.Point(851, 423);
            this.metroTile7.Name = "metroTile7";
            this.metroTile7.Size = new System.Drawing.Size(15, 14);
            this.metroTile7.TabIndex = 226;
            this.metroTile7.TileImage = ((System.Drawing.Image)(resources.GetObject("metroTile7.TileImage")));
            this.metroTile7.UseCustomBackColor = true;
            this.metroTile7.UseCustomForeColor = true;
            this.metroTile7.UseSelectable = true;
            this.metroTile7.UseStyleColors = true;
            this.metroTile7.UseTileImage = true;
            this.metroTile7.Click += new System.EventHandler(this.metroTile7_Click);
            // 
            // metroTile8
            // 
            this.metroTile8.ActiveControl = null;
            this.metroTile8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroTile8.Location = new System.Drawing.Point(788, 249);
            this.metroTile8.Name = "metroTile8";
            this.metroTile8.Size = new System.Drawing.Size(15, 14);
            this.metroTile8.TabIndex = 227;
            this.metroTile8.TileImage = ((System.Drawing.Image)(resources.GetObject("metroTile8.TileImage")));
            this.metroTile8.UseCustomBackColor = true;
            this.metroTile8.UseCustomForeColor = true;
            this.metroTile8.UseSelectable = true;
            this.metroTile8.UseStyleColors = true;
            this.metroTile8.UseTileImage = true;
            this.metroTile8.Click += new System.EventHandler(this.metroTile8_Click);
            // 
            // txts_start_date
            // 
            this.txts_start_date.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txts_start_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txts_start_date.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txts_start_date.Location = new System.Drawing.Point(599, 252);
            this.txts_start_date.Name = "txts_start_date";
            this.txts_start_date.Size = new System.Drawing.Size(183, 26);
            this.txts_start_date.TabIndex = 228;
            // 
            // txtbarcode
            // 
            this.txtbarcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbarcode.Location = new System.Drawing.Point(592, 372);
            this.txtbarcode.Name = "txtbarcode";
            this.txtbarcode.Size = new System.Drawing.Size(191, 29);
            this.txtbarcode.TabIndex = 182;
            this.txtbarcode.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtbarcode.TextChanged += new System.EventHandler(this.sid_TextChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(477, 377);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(110, 19);
            this.label22.TabIndex = 221;
            this.label22.Text = "Barcode # :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(93, 179);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(104, 19);
            this.label16.TabIndex = 230;
            this.label16.Text = "Student Id:";
            // 
            // txts_id
            // 
            this.txts_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txts_id.Location = new System.Drawing.Point(208, 174);
            this.txts_id.Name = "txts_id";
            this.txts_id.Size = new System.Drawing.Size(236, 29);
            this.txts_id.TabIndex = 229;
            this.txts_id.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // metroTile1
            // 
            this.metroTile1.ActiveControl = null;
            this.metroTile1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroTile1.Location = new System.Drawing.Point(399, 504);
            this.metroTile1.Name = "metroTile1";
            this.metroTile1.Size = new System.Drawing.Size(15, 14);
            this.metroTile1.TabIndex = 231;
            this.metroTile1.TileImage = ((System.Drawing.Image)(resources.GetObject("metroTile1.TileImage")));
            this.metroTile1.UseCustomBackColor = true;
            this.metroTile1.UseCustomForeColor = true;
            this.metroTile1.UseSelectable = true;
            this.metroTile1.UseStyleColors = true;
            this.metroTile1.UseTileImage = true;
            this.metroTile1.Click += new System.EventHandler(this.metroTile1_Click);
            // 
            // edit10
            // 
            this.edit10.ActiveControl = null;
            this.edit10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.edit10.Location = new System.Drawing.Point(788, 291);
            this.edit10.Name = "edit10";
            this.edit10.Size = new System.Drawing.Size(15, 14);
            this.edit10.TabIndex = 149;
            this.edit10.TileImage = ((System.Drawing.Image)(resources.GetObject("edit10.TileImage")));
            this.edit10.UseCustomBackColor = true;
            this.edit10.UseCustomForeColor = true;
            this.edit10.UseSelectable = true;
            this.edit10.UseStyleColors = true;
            this.edit10.UseTileImage = true;
            this.edit10.Click += new System.EventHandler(this.edit10_Click);
            // 
            // Add_Student
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1350, 620);
            this.Controls.Add(this.metroTile1);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.txts_id);
            this.Controls.Add(this.txts_start_date);
            this.Controls.Add(this.metroTile8);
            this.Controls.Add(this.metroTile7);
            this.Controls.Add(this.metroTile6);
            this.Controls.Add(this.metroTile5);
            this.Controls.Add(this.metroTile4);
            this.Controls.Add(this.metroTile3);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.txts_ready_password);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txts_country);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txts_zip_code);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txts_city);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txts_street);
            this.Controls.Add(this.metroTile2);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.txts_home_phone);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.txts_email);
            this.Controls.Add(this.txtstatus);
            this.Controls.Add(this.editstatusstudent);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.time);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.rollnos);
            this.Controls.Add(this.txtbarcode);
            this.Controls.Add(this.stueditrollnumber);
            this.Controls.Add(this.edit12);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.refreshbtn);
            this.Controls.Add(this.metroPanel1);
            this.Controls.Add(this.change_spic);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.edit8);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtsdob);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.btndeleteteac);
            this.Controls.Add(this.btnupdateteac);
            this.Controls.Add(this.txtsinsert);
            this.Controls.Add(this.edit11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.edit7);
            this.Controls.Add(this.edit10);
            this.Controls.Add(this.edit3);
            this.Controls.Add(this.edit2);
            this.Controls.Add(this.edit1);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txts_note);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.team_id);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txts_mobile_phone);
            this.Controls.Add(this.txtsgender);
            this.Controls.Add(this.txtsfnam);
            this.Controls.Add(this.txtsname);
            this.MaximizeBox = false;
            this.Name = "Add_Student";
            this.Text = "s";
            this.Load += new System.EventHandler(this.Add_Student_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label9;
        private MetroFramework.Controls.MetroTile edit7;
        private MetroFramework.Controls.MetroTile edit3;
        private MetroFramework.Controls.MetroTile edit2;
        private MetroFramework.Controls.MetroTile edit1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txts_note;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MaskedTextBox txts_mobile_phone;
        private System.Windows.Forms.ComboBox txtsgender;
        private System.Windows.Forms.TextBox txtsfnam;
        private System.Windows.Forms.TextBox txtsname;
        private MetroFramework.Controls.MetroTile edit11;
        private MetroFramework.Controls.MetroButton btndeleteteac;
        private MetroFramework.Controls.MetroButton btnupdateteac;
        private MetroFramework.Controls.MetroButton txtsinsert;
        private System.Windows.Forms.Label label15;
        private MetroFramework.Controls.MetroTile edit8;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.MaskedTextBox txtsdob;
        private MetroFramework.Controls.MetroButton change_spic;
        private System.Windows.Forms.PictureBox pictureBox3;
        private MetroFramework.Controls.MetroButton refreshbtn;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private System.Windows.Forms.MaskedTextBox txtsearchstudent;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private MetroFramework.Controls.MetroTile edit12;
        private MetroFramework.Controls.MetroTile stueditrollnumber;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.TextBox rollnos;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label time;
        private MetroFramework.Controls.MetroTile editstatusstudent;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox txtstatus;
        private System.Windows.Forms.TextBox txts_ready_password;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txts_country;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txts_zip_code;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txts_city;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txts_street;
        private MetroFramework.Controls.MetroTile metroTile2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.MaskedTextBox txts_home_phone;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txts_email;
        private System.Windows.Forms.ComboBox team_id;
        private MetroFramework.Controls.MetroTile metroTile8;
        private MetroFramework.Controls.MetroTile metroTile7;
        private MetroFramework.Controls.MetroTile metroTile6;
        private MetroFramework.Controls.MetroTile metroTile5;
        private MetroFramework.Controls.MetroTile metroTile4;
        private MetroFramework.Controls.MetroTile metroTile3;
        private System.Windows.Forms.DateTimePicker txts_start_date;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txts_id;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtbarcode;
        private MetroFramework.Controls.MetroTile metroTile1;
        private MetroFramework.Controls.MetroTile edit10;
    }
}