﻿namespace studentmanagementsystem
{
    partial class Add_Student
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Add_Student));
            this.label15 = new System.Windows.Forms.Label();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.txtsearchstudent = new System.Windows.Forms.MaskedTextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.metroTile11 = new MetroFramework.Controls.MetroTile();
            this.metroTile1 = new MetroFramework.Controls.MetroTile();
            this.label16 = new System.Windows.Forms.Label();
            this.txts_id = new System.Windows.Forms.TextBox();
            this.txts_start_date = new System.Windows.Forms.DateTimePicker();
            this.metroTile8 = new MetroFramework.Controls.MetroTile();
            this.metroTile7 = new MetroFramework.Controls.MetroTile();
            this.metroTile6 = new MetroFramework.Controls.MetroTile();
            this.metroTile10 = new MetroFramework.Controls.MetroTile();
            this.metroTile5 = new MetroFramework.Controls.MetroTile();
            this.txts_mobile_phone = new System.Windows.Forms.MaskedTextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btndeleteteac = new MetroFramework.Controls.MetroButton();
            this.metroTile4 = new MetroFramework.Controls.MetroTile();
            this.txtsinsert = new MetroFramework.Controls.MetroButton();
            this.metroTile3 = new MetroFramework.Controls.MetroTile();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.btnupdateteac = new MetroFramework.Controls.MetroButton();
            this.txts_note = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txts_ready_password = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.team_id = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.edit10 = new MetroFramework.Controls.MetroTile();
            this.txts_country = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txts_zip_code = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txts_state = new System.Windows.Forms.TextBox();
            this.txts_city = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txts_street = new System.Windows.Forms.TextBox();
            this.metroTile2 = new MetroFramework.Controls.MetroTile();
            this.label20 = new System.Windows.Forms.Label();
            this.txts_home_phone = new System.Windows.Forms.MaskedTextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txts_email = new System.Windows.Forms.TextBox();
            this.rollnos = new System.Windows.Forms.TextBox();
            this.stueditrollnumber = new MetroFramework.Controls.MetroTile();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.edit8 = new MetroFramework.Controls.MetroTile();
            this.label8 = new System.Windows.Forms.Label();
            this.txtsdob = new System.Windows.Forms.MaskedTextBox();
            this.edit11 = new MetroFramework.Controls.MetroTile();
            this.label9 = new System.Windows.Forms.Label();
            this.edit3 = new MetroFramework.Controls.MetroTile();
            this.edit2 = new MetroFramework.Controls.MetroTile();
            this.metroTile9 = new MetroFramework.Controls.MetroTile();
            this.edit1 = new MetroFramework.Controls.MetroTile();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtsgender = new System.Windows.Forms.ComboBox();
            this.txtsfnam = new System.Windows.Forms.TextBox();
            this.txtlastname = new System.Windows.Forms.TextBox();
            this.txtsname = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtbarcode = new System.Windows.Forms.TextBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.edit12 = new MetroFramework.Controls.MetroTile();
            this.refreshbtn = new MetroFramework.Controls.MetroButton();
            this.editstatusstudent = new MetroFramework.Controls.MetroTile();
            this.time = new System.Windows.Forms.Label();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Impact", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(142)))), ((int)(((byte)(107)))));
            this.label15.Location = new System.Drawing.Point(394, 47);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(295, 60);
            this.label15.TabIndex = 169;
            this.label15.Text = "ADD   STUDENT";
            // 
            // metroPanel1
            // 
            this.metroPanel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.metroPanel1.Controls.Add(this.txtsearchstudent);
            this.metroPanel1.Controls.Add(this.pictureBox2);
            this.metroPanel1.Controls.Add(this.label10);
            this.metroPanel1.Controls.Add(this.label12);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(1108, 320);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(285, 106);
            this.metroPanel1.TabIndex = 175;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // txtsearchstudent
            // 
            this.txtsearchstudent.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsearchstudent.Location = new System.Drawing.Point(71, 65);
            this.txtsearchstudent.Name = "txtsearchstudent";
            this.txtsearchstudent.Size = new System.Drawing.Size(184, 29);
            this.txtsearchstudent.TabIndex = 85;
            this.txtsearchstudent.TextChanged += new System.EventHandler(this.txtsearchstudent_TextChanged);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::studentmanagementsystem.Properties.Resources.search_icon;
            this.pictureBox2.Location = new System.Drawing.Point(21, 15);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(31, 26);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 84;
            this.pictureBox2.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(29, 21);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(201, 19);
            this.label10.TabIndex = 56;
            this.label10.Text = "Student\'s Search Panel";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(3, 71);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(66, 19);
            this.label12.TabIndex = 55;
            this.label12.Text = "Roll #:";
            // 
            // timer2
            // 
            this.timer2.Interval = 1000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox1.Controls.Add(this.metroButton1);
            this.groupBox1.Controls.Add(this.metroTile11);
            this.groupBox1.Controls.Add(this.metroTile1);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.txts_id);
            this.groupBox1.Controls.Add(this.txts_start_date);
            this.groupBox1.Controls.Add(this.metroTile8);
            this.groupBox1.Controls.Add(this.metroTile7);
            this.groupBox1.Controls.Add(this.metroTile6);
            this.groupBox1.Controls.Add(this.metroTile10);
            this.groupBox1.Controls.Add(this.metroTile5);
            this.groupBox1.Controls.Add(this.txts_mobile_phone);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.btndeleteteac);
            this.groupBox1.Controls.Add(this.metroTile4);
            this.groupBox1.Controls.Add(this.txtsinsert);
            this.groupBox1.Controls.Add(this.metroTile3);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.btnupdateteac);
            this.groupBox1.Controls.Add(this.txts_note);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.txts_ready_password);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.team_id);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.edit10);
            this.groupBox1.Controls.Add(this.txts_country);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.txts_zip_code);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txts_state);
            this.groupBox1.Controls.Add(this.txts_city);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txts_street);
            this.groupBox1.Controls.Add(this.metroTile2);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.txts_home_phone);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.txts_email);
            this.groupBox1.Controls.Add(this.rollnos);
            this.groupBox1.Controls.Add(this.stueditrollnumber);
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Controls.Add(this.edit8);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txtsdob);
            this.groupBox1.Controls.Add(this.edit11);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.edit3);
            this.groupBox1.Controls.Add(this.edit2);
            this.groupBox1.Controls.Add(this.metroTile9);
            this.groupBox1.Controls.Add(this.edit1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtsgender);
            this.groupBox1.Controls.Add(this.txtsfnam);
            this.groupBox1.Controls.Add(this.txtlastname);
            this.groupBox1.Controls.Add(this.txtsname);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(46, 137);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(984, 541);
            this.groupBox1.TabIndex = 232;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Enter Student Details:";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // metroButton1
            // 
            this.metroButton1.BackColor = System.Drawing.Color.White;
            this.metroButton1.BackgroundImage = global::studentmanagementsystem.Properties.Resources.search_icon;
            this.metroButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.metroButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroButton1.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.metroButton1.ForeColor = System.Drawing.Color.Transparent;
            this.metroButton1.Location = new System.Drawing.Point(345, 64);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(28, 28);
            this.metroButton1.TabIndex = 293;
            this.metroButton1.UseCustomBackColor = true;
            this.metroButton1.UseCustomForeColor = true;
            this.metroButton1.UseSelectable = true;
            this.metroButton1.UseStyleColors = true;
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // metroTile11
            // 
            this.metroTile11.ActiveControl = null;
            this.metroTile11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroTile11.Location = new System.Drawing.Point(397, 250);
            this.metroTile11.Name = "metroTile11";
            this.metroTile11.Size = new System.Drawing.Size(15, 14);
            this.metroTile11.TabIndex = 292;
            this.metroTile11.TileImage = ((System.Drawing.Image)(resources.GetObject("metroTile11.TileImage")));
            this.metroTile11.UseCustomBackColor = true;
            this.metroTile11.UseCustomForeColor = true;
            this.metroTile11.UseSelectable = true;
            this.metroTile11.UseStyleColors = true;
            this.metroTile11.UseTileImage = true;
            this.metroTile11.Click += new System.EventHandler(this.metroTile11_Click);
            // 
            // metroTile1
            // 
            this.metroTile1.ActiveControl = null;
            this.metroTile1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroTile1.Location = new System.Drawing.Point(926, 418);
            this.metroTile1.Name = "metroTile1";
            this.metroTile1.Size = new System.Drawing.Size(15, 14);
            this.metroTile1.TabIndex = 291;
            this.metroTile1.TileImage = ((System.Drawing.Image)(resources.GetObject("metroTile1.TileImage")));
            this.metroTile1.UseCustomBackColor = true;
            this.metroTile1.UseCustomForeColor = true;
            this.metroTile1.UseSelectable = true;
            this.metroTile1.UseStyleColors = true;
            this.metroTile1.UseTileImage = true;
            this.metroTile1.Click += new System.EventHandler(this.metroTile1_Click_1);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(55, 37);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(87, 17);
            this.label16.TabIndex = 290;
            this.label16.Text = "Student Id:";
            // 
            // txts_id
            // 
            this.txts_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txts_id.Location = new System.Drawing.Point(154, 35);
            this.txts_id.Name = "txts_id";
            this.txts_id.Size = new System.Drawing.Size(233, 23);
            this.txts_id.TabIndex = 0;
            this.txts_id.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txts_start_date
            // 
            this.txts_start_date.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txts_start_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txts_start_date.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txts_start_date.Location = new System.Drawing.Point(584, 190);
            this.txts_start_date.Name = "txts_start_date";
            this.txts_start_date.Size = new System.Drawing.Size(323, 23);
            this.txts_start_date.TabIndex = 16;
            // 
            // metroTile8
            // 
            this.metroTile8.ActiveControl = null;
            this.metroTile8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroTile8.Location = new System.Drawing.Point(912, 189);
            this.metroTile8.Name = "metroTile8";
            this.metroTile8.Size = new System.Drawing.Size(15, 14);
            this.metroTile8.TabIndex = 287;
            this.metroTile8.TileImage = ((System.Drawing.Image)(resources.GetObject("metroTile8.TileImage")));
            this.metroTile8.UseCustomBackColor = true;
            this.metroTile8.UseCustomForeColor = true;
            this.metroTile8.UseSelectable = true;
            this.metroTile8.UseStyleColors = true;
            this.metroTile8.UseTileImage = true;
            this.metroTile8.Click += new System.EventHandler(this.metroTile8_Click_1);
            // 
            // metroTile7
            // 
            this.metroTile7.ActiveControl = null;
            this.metroTile7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroTile7.Location = new System.Drawing.Point(394, 485);
            this.metroTile7.Name = "metroTile7";
            this.metroTile7.Size = new System.Drawing.Size(15, 14);
            this.metroTile7.TabIndex = 286;
            this.metroTile7.TileImage = ((System.Drawing.Image)(resources.GetObject("metroTile7.TileImage")));
            this.metroTile7.UseCustomBackColor = true;
            this.metroTile7.UseCustomForeColor = true;
            this.metroTile7.UseSelectable = true;
            this.metroTile7.UseStyleColors = true;
            this.metroTile7.UseTileImage = true;
            this.metroTile7.Click += new System.EventHandler(this.metroTile7_Click_1);
            // 
            // metroTile6
            // 
            this.metroTile6.ActiveControl = null;
            this.metroTile6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroTile6.Location = new System.Drawing.Point(395, 451);
            this.metroTile6.Name = "metroTile6";
            this.metroTile6.Size = new System.Drawing.Size(15, 14);
            this.metroTile6.TabIndex = 285;
            this.metroTile6.TileImage = ((System.Drawing.Image)(resources.GetObject("metroTile6.TileImage")));
            this.metroTile6.UseCustomBackColor = true;
            this.metroTile6.UseCustomForeColor = true;
            this.metroTile6.UseSelectable = true;
            this.metroTile6.UseStyleColors = true;
            this.metroTile6.UseTileImage = true;
            this.metroTile6.Click += new System.EventHandler(this.metroTile6_Click_1);
            // 
            // metroTile10
            // 
            this.metroTile10.ActiveControl = null;
            this.metroTile10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroTile10.Location = new System.Drawing.Point(393, 415);
            this.metroTile10.Name = "metroTile10";
            this.metroTile10.Size = new System.Drawing.Size(15, 14);
            this.metroTile10.TabIndex = 284;
            this.metroTile10.TileImage = ((System.Drawing.Image)(resources.GetObject("metroTile10.TileImage")));
            this.metroTile10.UseCustomBackColor = true;
            this.metroTile10.UseCustomForeColor = true;
            this.metroTile10.UseSelectable = true;
            this.metroTile10.UseStyleColors = true;
            this.metroTile10.UseTileImage = true;
            this.metroTile10.Click += new System.EventHandler(this.metroTile10_Click);
            // 
            // metroTile5
            // 
            this.metroTile5.ActiveControl = null;
            this.metroTile5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroTile5.Location = new System.Drawing.Point(393, 381);
            this.metroTile5.Name = "metroTile5";
            this.metroTile5.Size = new System.Drawing.Size(15, 14);
            this.metroTile5.TabIndex = 284;
            this.metroTile5.TileImage = ((System.Drawing.Image)(resources.GetObject("metroTile5.TileImage")));
            this.metroTile5.UseCustomBackColor = true;
            this.metroTile5.UseCustomForeColor = true;
            this.metroTile5.UseSelectable = true;
            this.metroTile5.UseStyleColors = true;
            this.metroTile5.UseTileImage = true;
            this.metroTile5.Click += new System.EventHandler(this.metroTile5_Click_1);
            // 
            // txts_mobile_phone
            // 
            this.txts_mobile_phone.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txts_mobile_phone.Location = new System.Drawing.Point(153, 250);
            this.txts_mobile_phone.Name = "txts_mobile_phone";
            this.txts_mobile_phone.Size = new System.Drawing.Size(234, 23);
            this.txts_mobile_phone.TabIndex = 7;
            this.txts_mobile_phone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txts_mobile_phone_KeyPress);
            this.txts_mobile_phone.Leave += new System.EventHandler(this.txts_mobile_phone_Leave);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(89, 412);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(51, 17);
            this.label17.TabIndex = 275;
            this.label17.Text = "State:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(64, 256);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 17);
            this.label6.TabIndex = 243;
            this.label6.Text = "Mobile  #:";
            // 
            // btndeleteteac
            // 
            this.btndeleteteac.BackColor = System.Drawing.Color.IndianRed;
            this.btndeleteteac.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btndeleteteac.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.btndeleteteac.ForeColor = System.Drawing.Color.White;
            this.btndeleteteac.Location = new System.Drawing.Point(592, 463);
            this.btndeleteteac.Name = "btndeleteteac";
            this.btndeleteteac.Size = new System.Drawing.Size(154, 36);
            this.btndeleteteac.TabIndex = 254;
            this.btndeleteteac.Text = "Delete";
            this.btndeleteteac.UseCustomBackColor = true;
            this.btndeleteteac.UseCustomForeColor = true;
            this.btndeleteteac.UseSelectable = true;
            this.btndeleteteac.UseStyleColors = true;
            this.btndeleteteac.Click += new System.EventHandler(this.btndeleteteac_Click_1);
            // 
            // metroTile4
            // 
            this.metroTile4.ActiveControl = null;
            this.metroTile4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroTile4.Location = new System.Drawing.Point(394, 350);
            this.metroTile4.Name = "metroTile4";
            this.metroTile4.Size = new System.Drawing.Size(15, 14);
            this.metroTile4.TabIndex = 283;
            this.metroTile4.TileImage = ((System.Drawing.Image)(resources.GetObject("metroTile4.TileImage")));
            this.metroTile4.UseCustomBackColor = true;
            this.metroTile4.UseCustomForeColor = true;
            this.metroTile4.UseSelectable = true;
            this.metroTile4.UseStyleColors = true;
            this.metroTile4.UseTileImage = true;
            this.metroTile4.Click += new System.EventHandler(this.metroTile4_Click_1);
            // 
            // txtsinsert
            // 
            this.txtsinsert.BackColor = System.Drawing.Color.Teal;
            this.txtsinsert.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtsinsert.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.txtsinsert.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtsinsert.Location = new System.Drawing.Point(752, 463);
            this.txtsinsert.Name = "txtsinsert";
            this.txtsinsert.Size = new System.Drawing.Size(154, 36);
            this.txtsinsert.TabIndex = 20;
            this.txtsinsert.Text = "Save";
            this.txtsinsert.UseCustomBackColor = true;
            this.txtsinsert.UseCustomForeColor = true;
            this.txtsinsert.UseSelectable = true;
            this.txtsinsert.UseStyleColors = true;
            this.txtsinsert.Click += new System.EventHandler(this.txtsinsert_Click);
            // 
            // metroTile3
            // 
            this.metroTile3.ActiveControl = null;
            this.metroTile3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroTile3.Location = new System.Drawing.Point(395, 283);
            this.metroTile3.Name = "metroTile3";
            this.metroTile3.Size = new System.Drawing.Size(15, 14);
            this.metroTile3.TabIndex = 282;
            this.metroTile3.TileImage = ((System.Drawing.Image)(resources.GetObject("metroTile3.TileImage")));
            this.metroTile3.UseCustomBackColor = true;
            this.metroTile3.UseCustomForeColor = true;
            this.metroTile3.UseSelectable = true;
            this.metroTile3.UseStyleColors = true;
            this.metroTile3.UseTileImage = true;
            this.metroTile3.Click += new System.EventHandler(this.metroTile3_Click_1);
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(584, 67);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(158, 107);
            this.textBox2.TabIndex = 15;
            // 
            // btnupdateteac
            // 
            this.btnupdateteac.BackColor = System.Drawing.Color.Gold;
            this.btnupdateteac.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnupdateteac.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.btnupdateteac.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnupdateteac.Location = new System.Drawing.Point(752, 463);
            this.btnupdateteac.Name = "btnupdateteac";
            this.btnupdateteac.Size = new System.Drawing.Size(154, 36);
            this.btnupdateteac.TabIndex = 253;
            this.btnupdateteac.Text = "Update";
            this.btnupdateteac.UseCustomBackColor = true;
            this.btnupdateteac.UseCustomForeColor = true;
            this.btnupdateteac.UseSelectable = true;
            this.btnupdateteac.UseStyleColors = true;
            this.btnupdateteac.Click += new System.EventHandler(this.btnupdateteac_Click_1);
            // 
            // txts_note
            // 
            this.txts_note.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txts_note.Location = new System.Drawing.Point(584, 310);
            this.txts_note.Multiline = true;
            this.txts_note.Name = "txts_note";
            this.txts_note.Size = new System.Drawing.Size(323, 140);
            this.txts_note.TabIndex = 19;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(463, 69);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(123, 19);
            this.label24.TabIndex = 245;
            this.label24.Text = "Attachments:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(524, 309);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(57, 19);
            this.label14.TabIndex = 245;
            this.label14.Text = "Note:";
            // 
            // txts_ready_password
            // 
            this.txts_ready_password.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txts_ready_password.Location = new System.Drawing.Point(584, 270);
            this.txts_ready_password.Name = "txts_ready_password";
            this.txts_ready_password.Size = new System.Drawing.Size(323, 23);
            this.txts_ready_password.TabIndex = 18;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(433, 267);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(154, 19);
            this.label21.TabIndex = 279;
            this.label21.Text = "Ready Password:";
            // 
            // team_id
            // 
            this.team_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.team_id.FormattingEnabled = true;
            this.team_id.Items.AddRange(new object[] {
            "Select Team"});
            this.team_id.Location = new System.Drawing.Point(584, 230);
            this.team_id.Name = "team_id";
            this.team_id.Size = new System.Drawing.Size(323, 25);
            this.team_id.TabIndex = 17;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(518, 228);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 19);
            this.label7.TabIndex = 244;
            this.label7.Text = "Team:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(71, 478);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(69, 17);
            this.label13.TabIndex = 277;
            this.label13.Text = "Country:";
            // 
            // edit10
            // 
            this.edit10.ActiveControl = null;
            this.edit10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.edit10.Location = new System.Drawing.Point(912, 233);
            this.edit10.Name = "edit10";
            this.edit10.Size = new System.Drawing.Size(15, 14);
            this.edit10.TabIndex = 249;
            this.edit10.TileImage = ((System.Drawing.Image)(resources.GetObject("edit10.TileImage")));
            this.edit10.UseCustomBackColor = true;
            this.edit10.UseCustomForeColor = true;
            this.edit10.UseSelectable = true;
            this.edit10.UseStyleColors = true;
            this.edit10.UseTileImage = true;
            this.edit10.Click += new System.EventHandler(this.edit10_Click_1);
            // 
            // txts_country
            // 
            this.txts_country.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txts_country.Location = new System.Drawing.Point(153, 476);
            this.txts_country.Name = "txts_country";
            this.txts_country.Size = new System.Drawing.Size(234, 23);
            this.txts_country.TabIndex = 14;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(479, 190);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(104, 19);
            this.label18.TabIndex = 278;
            this.label18.Text = "Start Date:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(66, 448);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(78, 17);
            this.label11.TabIndex = 275;
            this.label11.Text = "Zip Code:";
            // 
            // txts_zip_code
            // 
            this.txts_zip_code.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txts_zip_code.Location = new System.Drawing.Point(152, 446);
            this.txts_zip_code.Name = "txts_zip_code";
            this.txts_zip_code.Size = new System.Drawing.Size(234, 23);
            this.txts_zip_code.TabIndex = 13;
            this.txts_zip_code.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txts_zip_code_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(98, 379);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 17);
            this.label5.TabIndex = 273;
            this.label5.Text = "City:";
            // 
            // txts_state
            // 
            this.txts_state.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txts_state.Location = new System.Drawing.Point(152, 410);
            this.txts_state.Name = "txts_state";
            this.txts_state.Size = new System.Drawing.Size(234, 23);
            this.txts_state.TabIndex = 12;
            // 
            // txts_city
            // 
            this.txts_city.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txts_city.Location = new System.Drawing.Point(152, 376);
            this.txts_city.Name = "txts_city";
            this.txts_city.Size = new System.Drawing.Size(234, 23);
            this.txts_city.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(84, 349);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 17);
            this.label1.TabIndex = 271;
            this.label1.Text = "Street:";
            // 
            // txts_street
            // 
            this.txts_street.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txts_street.Location = new System.Drawing.Point(152, 346);
            this.txts_street.Name = "txts_street";
            this.txts_street.Size = new System.Drawing.Size(234, 23);
            this.txts_street.TabIndex = 10;
            // 
            // metroTile2
            // 
            this.metroTile2.ActiveControl = null;
            this.metroTile2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroTile2.Location = new System.Drawing.Point(397, 223);
            this.metroTile2.Name = "metroTile2";
            this.metroTile2.Size = new System.Drawing.Size(15, 14);
            this.metroTile2.TabIndex = 269;
            this.metroTile2.TileImage = ((System.Drawing.Image)(resources.GetObject("metroTile2.TileImage")));
            this.metroTile2.UseCustomBackColor = true;
            this.metroTile2.UseCustomForeColor = true;
            this.metroTile2.UseSelectable = true;
            this.metroTile2.UseStyleColors = true;
            this.metroTile2.UseTileImage = true;
            this.metroTile2.Click += new System.EventHandler(this.metroTile2_Click_1);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(71, 283);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(73, 17);
            this.label20.TabIndex = 268;
            this.label20.Text = "Home  #:";
            // 
            // txts_home_phone
            // 
            this.txts_home_phone.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txts_home_phone.Location = new System.Drawing.Point(153, 280);
            this.txts_home_phone.Name = "txts_home_phone";
            this.txts_home_phone.Size = new System.Drawing.Size(234, 23);
            this.txts_home_phone.TabIndex = 8;
            this.txts_home_phone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txts_home_phone_KeyPress_1);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(67, 223);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(76, 17);
            this.label19.TabIndex = 266;
            this.label19.Text = "E-mail Id:";
            // 
            // txts_email
            // 
            this.txts_email.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txts_email.Location = new System.Drawing.Point(154, 220);
            this.txts_email.Name = "txts_email";
            this.txts_email.Size = new System.Drawing.Size(235, 23);
            this.txts_email.TabIndex = 6;
            this.txts_email.Leave += new System.EventHandler(this.txts_email_Leave);
            // 
            // rollnos
            // 
            this.rollnos.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rollnos.Location = new System.Drawing.Point(154, 66);
            this.rollnos.Name = "rollnos";
            this.rollnos.Size = new System.Drawing.Size(185, 23);
            this.rollnos.TabIndex = 1;
            this.rollnos.TextChanged += new System.EventHandler(this.rollnos_TextChanged);
            this.rollnos.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.rollnos_KeyPress);
            this.rollnos.Leave += new System.EventHandler(this.rollnos_Leave);
            // 
            // stueditrollnumber
            // 
            this.stueditrollnumber.ActiveControl = null;
            this.stueditrollnumber.Cursor = System.Windows.Forms.Cursors.Hand;
            this.stueditrollnumber.Location = new System.Drawing.Point(397, 70);
            this.stueditrollnumber.Name = "stueditrollnumber";
            this.stueditrollnumber.Size = new System.Drawing.Size(15, 14);
            this.stueditrollnumber.TabIndex = 259;
            this.stueditrollnumber.TileImage = ((System.Drawing.Image)(resources.GetObject("stueditrollnumber.TileImage")));
            this.stueditrollnumber.UseCustomBackColor = true;
            this.stueditrollnumber.UseCustomForeColor = true;
            this.stueditrollnumber.UseSelectable = true;
            this.stueditrollnumber.UseStyleColors = true;
            this.stueditrollnumber.UseTileImage = true;
            this.stueditrollnumber.Click += new System.EventHandler(this.stueditrollnumber_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.White;
            this.pictureBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox3.Image = global::studentmanagementsystem.Properties.Resources._13_512;
            this.pictureBox3.Location = new System.Drawing.Point(772, 32);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(130, 142);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 257;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click_1);
            // 
            // edit8
            // 
            this.edit8.ActiveControl = null;
            this.edit8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.edit8.Location = new System.Drawing.Point(395, 314);
            this.edit8.Name = "edit8";
            this.edit8.Size = new System.Drawing.Size(15, 14);
            this.edit8.TabIndex = 256;
            this.edit8.TileImage = ((System.Drawing.Image)(resources.GetObject("edit8.TileImage")));
            this.edit8.UseCustomBackColor = true;
            this.edit8.UseCustomForeColor = true;
            this.edit8.UseSelectable = true;
            this.edit8.UseStyleColors = true;
            this.edit8.UseTileImage = true;
            this.edit8.Click += new System.EventHandler(this.edit8_Click_1);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(96, 313);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 17);
            this.label8.TabIndex = 255;
            this.label8.Text = "DOB:";
            // 
            // txtsdob
            // 
            this.txtsdob.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsdob.Location = new System.Drawing.Point(152, 310);
            this.txtsdob.Mask = "99-99-9999";
            this.txtsdob.Name = "txtsdob";
            this.txtsdob.Size = new System.Drawing.Size(234, 23);
            this.txtsdob.TabIndex = 9;
            // 
            // edit11
            // 
            this.edit11.ActiveControl = null;
            this.edit11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.edit11.Location = new System.Drawing.Point(912, 271);
            this.edit11.Name = "edit11";
            this.edit11.Size = new System.Drawing.Size(15, 14);
            this.edit11.TabIndex = 252;
            this.edit11.TileImage = ((System.Drawing.Image)(resources.GetObject("edit11.TileImage")));
            this.edit11.UseCustomBackColor = true;
            this.edit11.UseCustomForeColor = true;
            this.edit11.UseSelectable = true;
            this.edit11.UseStyleColors = true;
            this.edit11.UseTileImage = true;
            this.edit11.Click += new System.EventHandler(this.edit11_Click_1);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(89, 68);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 17);
            this.label9.TabIndex = 251;
            this.label9.Text = "Roll #:";
            // 
            // edit3
            // 
            this.edit3.ActiveControl = null;
            this.edit3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.edit3.Location = new System.Drawing.Point(397, 192);
            this.edit3.Name = "edit3";
            this.edit3.Size = new System.Drawing.Size(15, 14);
            this.edit3.TabIndex = 248;
            this.edit3.TileImage = ((System.Drawing.Image)(resources.GetObject("edit3.TileImage")));
            this.edit3.UseCustomBackColor = true;
            this.edit3.UseCustomForeColor = true;
            this.edit3.UseSelectable = true;
            this.edit3.UseStyleColors = true;
            this.edit3.UseTileImage = true;
            this.edit3.Click += new System.EventHandler(this.edit3_Click_1);
            // 
            // edit2
            // 
            this.edit2.ActiveControl = null;
            this.edit2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.edit2.Location = new System.Drawing.Point(397, 161);
            this.edit2.Name = "edit2";
            this.edit2.Size = new System.Drawing.Size(15, 14);
            this.edit2.TabIndex = 247;
            this.edit2.TileImage = ((System.Drawing.Image)(resources.GetObject("edit2.TileImage")));
            this.edit2.UseCustomBackColor = true;
            this.edit2.UseCustomForeColor = true;
            this.edit2.UseSelectable = true;
            this.edit2.UseStyleColors = true;
            this.edit2.UseTileImage = true;
            this.edit2.Click += new System.EventHandler(this.edit2_Click_1);
            // 
            // metroTile9
            // 
            this.metroTile9.ActiveControl = null;
            this.metroTile9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroTile9.Location = new System.Drawing.Point(397, 130);
            this.metroTile9.Name = "metroTile9";
            this.metroTile9.Size = new System.Drawing.Size(15, 14);
            this.metroTile9.TabIndex = 246;
            this.metroTile9.TileImage = ((System.Drawing.Image)(resources.GetObject("metroTile9.TileImage")));
            this.metroTile9.UseCustomBackColor = true;
            this.metroTile9.UseCustomForeColor = true;
            this.metroTile9.UseSelectable = true;
            this.metroTile9.UseStyleColors = true;
            this.metroTile9.UseTileImage = true;
            this.metroTile9.Click += new System.EventHandler(this.metroTile9_Click);
            // 
            // edit1
            // 
            this.edit1.ActiveControl = null;
            this.edit1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.edit1.Location = new System.Drawing.Point(397, 99);
            this.edit1.Name = "edit1";
            this.edit1.Size = new System.Drawing.Size(15, 14);
            this.edit1.TabIndex = 246;
            this.edit1.TileImage = ((System.Drawing.Image)(resources.GetObject("edit1.TileImage")));
            this.edit1.UseCustomBackColor = true;
            this.edit1.UseCustomForeColor = true;
            this.edit1.UseSelectable = true;
            this.edit1.UseStyleColors = true;
            this.edit1.UseTileImage = true;
            this.edit1.Click += new System.EventHandler(this.edit1_Click_1);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(75, 192);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 17);
            this.label4.TabIndex = 242;
            this.label4.Text = "Gender:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(41, 161);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 17);
            this.label3.TabIndex = 241;
            this.label3.Text = "Father Name:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(57, 130);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(90, 17);
            this.label23.TabIndex = 240;
            this.label23.Text = "Last Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(55, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 17);
            this.label2.TabIndex = 240;
            this.label2.Text = "First Name:";
            // 
            // txtsgender
            // 
            this.txtsgender.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsgender.FormattingEnabled = true;
            this.txtsgender.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.txtsgender.Location = new System.Drawing.Point(154, 189);
            this.txtsgender.Name = "txtsgender";
            this.txtsgender.Size = new System.Drawing.Size(234, 25);
            this.txtsgender.TabIndex = 5;
            // 
            // txtsfnam
            // 
            this.txtsfnam.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsfnam.Location = new System.Drawing.Point(154, 158);
            this.txtsfnam.Name = "txtsfnam";
            this.txtsfnam.Size = new System.Drawing.Size(234, 23);
            this.txtsfnam.TabIndex = 4;
            this.txtsfnam.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtsfnam_KeyPress_1);
            this.txtsfnam.Leave += new System.EventHandler(this.txtsfnam_Leave_1);
            // 
            // txtlastname
            // 
            this.txtlastname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtlastname.Location = new System.Drawing.Point(154, 128);
            this.txtlastname.Name = "txtlastname";
            this.txtlastname.Size = new System.Drawing.Size(234, 23);
            this.txtlastname.TabIndex = 3;
            this.txtlastname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtlastname_KeyPress);
            // 
            // txtsname
            // 
            this.txtsname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsname.Location = new System.Drawing.Point(154, 97);
            this.txtsname.Name = "txtsname";
            this.txtsname.Size = new System.Drawing.Size(234, 23);
            this.txtsname.TabIndex = 2;
            this.txtsname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtsname_KeyPress_1);
            this.txtsname.Leave += new System.EventHandler(this.txtsname_Leave_1);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(1055, 492);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(92, 17);
            this.label22.TabIndex = 281;
            this.label22.Text = "Barcode # :";
            // 
            // txtbarcode
            // 
            this.txtbarcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbarcode.Location = new System.Drawing.Point(1148, 485);
            this.txtbarcode.Name = "txtbarcode";
            this.txtbarcode.Size = new System.Drawing.Size(191, 23);
            this.txtbarcode.TabIndex = 260;
            this.txtbarcode.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(16, 17);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(149, 91);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 185;
            this.pictureBox4.TabStop = false;
            // 
            // edit12
            // 
            this.edit12.ActiveControl = null;
            this.edit12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.edit12.Location = new System.Drawing.Point(988, 209);
            this.edit12.Name = "edit12";
            this.edit12.Size = new System.Drawing.Size(15, 14);
            this.edit12.TabIndex = 178;
            this.edit12.TileImage = ((System.Drawing.Image)(resources.GetObject("edit12.TileImage")));
            this.edit12.UseCustomBackColor = true;
            this.edit12.UseCustomForeColor = true;
            this.edit12.UseSelectable = true;
            this.edit12.UseStyleColors = true;
            this.edit12.UseTileImage = true;
            this.edit12.Click += new System.EventHandler(this.edit12_Click);
            // 
            // refreshbtn
            // 
            this.refreshbtn.BackColor = System.Drawing.Color.Transparent;
            this.refreshbtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("refreshbtn.BackgroundImage")));
            this.refreshbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.refreshbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.refreshbtn.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.refreshbtn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.refreshbtn.Location = new System.Drawing.Point(983, 89);
            this.refreshbtn.Name = "refreshbtn";
            this.refreshbtn.Size = new System.Drawing.Size(47, 43);
            this.refreshbtn.TabIndex = 176;
            this.refreshbtn.UseCustomBackColor = true;
            this.refreshbtn.UseCustomForeColor = true;
            this.refreshbtn.UseSelectable = true;
            this.refreshbtn.UseStyleColors = true;
            this.refreshbtn.Click += new System.EventHandler(this.refreshbtn_Click);
            // 
            // editstatusstudent
            // 
            this.editstatusstudent.ActiveControl = null;
            this.editstatusstudent.Cursor = System.Windows.Forms.Cursors.Hand;
            this.editstatusstudent.Location = new System.Drawing.Point(1376, 554);
            this.editstatusstudent.Name = "editstatusstudent";
            this.editstatusstudent.Size = new System.Drawing.Size(15, 14);
            this.editstatusstudent.TabIndex = 263;
            this.editstatusstudent.TileImage = ((System.Drawing.Image)(resources.GetObject("editstatusstudent.TileImage")));
            this.editstatusstudent.UseCustomBackColor = true;
            this.editstatusstudent.UseCustomForeColor = true;
            this.editstatusstudent.UseSelectable = true;
            this.editstatusstudent.UseStyleColors = true;
            this.editstatusstudent.UseTileImage = true;
            // 
            // time
            // 
            this.time.AutoSize = true;
            this.time.BackColor = System.Drawing.Color.Transparent;
            this.time.Font = new System.Drawing.Font("DS-Digital", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.time.ForeColor = System.Drawing.Color.Maroon;
            this.time.Location = new System.Drawing.Point(849, 60);
            this.time.Name = "time";
            this.time.Size = new System.Drawing.Size(124, 31);
            this.time.TabIndex = 282;
            this.time.Text = "00:00:00";
            // 
            // Add_Student
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1028, 627);
            this.Controls.Add(this.time);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.edit12);
            this.Controls.Add(this.refreshbtn);
            this.Controls.Add(this.metroPanel1);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.txtbarcode);
            this.Controls.Add(this.editstatusstudent);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Add_Student";
            this.Style = MetroFramework.MetroColorStyle.Teal;
            this.Text = "Add Student";
            this.Load += new System.EventHandler(this.Add_Student_Load);
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label15;
        private MetroFramework.Controls.MetroButton refreshbtn;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private System.Windows.Forms.MaskedTextBox txtsearchstudent;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private MetroFramework.Controls.MetroTile edit12;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private MetroFramework.Controls.MetroTile editstatusstudent;
        private System.Windows.Forms.TextBox txtbarcode;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label17;
        public MetroFramework.Controls.MetroTile metroTile1;
        public System.Windows.Forms.TextBox txts_id;
        public System.Windows.Forms.DateTimePicker txts_start_date;
        public MetroFramework.Controls.MetroTile metroTile8;
        public MetroFramework.Controls.MetroTile metroTile7;
        public MetroFramework.Controls.MetroTile metroTile6;
        public MetroFramework.Controls.MetroTile metroTile5;
        public MetroFramework.Controls.MetroTile metroTile4;
        public MetroFramework.Controls.MetroTile metroTile3;
        public System.Windows.Forms.TextBox txts_ready_password;
        public System.Windows.Forms.TextBox txts_country;
        public System.Windows.Forms.TextBox txts_zip_code;
        public System.Windows.Forms.TextBox txts_city;
        public System.Windows.Forms.TextBox txts_street;
        public MetroFramework.Controls.MetroTile metroTile2;
        public System.Windows.Forms.MaskedTextBox txts_home_phone;
        public System.Windows.Forms.TextBox txts_email;
        public System.Windows.Forms.TextBox rollnos;
        public MetroFramework.Controls.MetroTile stueditrollnumber;
        public System.Windows.Forms.PictureBox pictureBox3;
        public MetroFramework.Controls.MetroTile edit8;
        public System.Windows.Forms.MaskedTextBox txtsdob;
        public MetroFramework.Controls.MetroButton btndeleteteac;
        public MetroFramework.Controls.MetroButton btnupdateteac;
        public MetroFramework.Controls.MetroButton txtsinsert;
        public MetroFramework.Controls.MetroTile edit11;
        public MetroFramework.Controls.MetroTile edit10;
        public MetroFramework.Controls.MetroTile edit3;
        public MetroFramework.Controls.MetroTile edit2;
        public MetroFramework.Controls.MetroTile metroTile9;
        public MetroFramework.Controls.MetroTile edit1;
        public System.Windows.Forms.TextBox txts_note;
        public System.Windows.Forms.ComboBox team_id;
        public System.Windows.Forms.MaskedTextBox txts_mobile_phone;
        public System.Windows.Forms.ComboBox txtsgender;
        public System.Windows.Forms.TextBox txtsfnam;
        public System.Windows.Forms.TextBox txtlastname;
        public System.Windows.Forms.TextBox txtsname;
        public System.Windows.Forms.TextBox textBox2;
        public MetroFramework.Controls.MetroTile metroTile10;
        public System.Windows.Forms.TextBox txts_state;
        public MetroFramework.Controls.MetroTile metroTile11;
        public MetroFramework.Controls.MetroButton metroButton1;
        private System.Windows.Forms.Label time;
    }
}