﻿namespace studentmanagementsystem
{
    partial class collect_advancefee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(collect_advancefee));
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.refreshbtn = new MetroFramework.Controls.MetroButton();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.Advacne = new System.Windows.Forms.Label();
            this.txtadvance = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtpeegender = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtfeestudentclass = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtfeestudentsection = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtfeestudentname = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtfeefathername = new System.Windows.Forms.TextBox();
            this.txtfeestudentrollno = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.txtcombox = new MetroFramework.Controls.MetroComboBox();
            this.txtsearch = new MetroFramework.Controls.MetroTextBox();
            this.btnexport = new MetroFramework.Controls.MetroButton();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("DS-Digital", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Crimson;
            this.label16.Location = new System.Drawing.Point(784, 25);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(124, 31);
            this.label16.TabIndex = 180;
            this.label16.Text = "00:00:00";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Forte", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.SlateGray;
            this.label15.Location = new System.Drawing.Point(289, 44);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(432, 41);
            this.label15.TabIndex = 178;
            this.label15.Text = "COLLECT-ADVANCE-FEE";
            // 
            // refreshbtn
            // 
            this.refreshbtn.BackColor = System.Drawing.Color.Transparent;
            this.refreshbtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("refreshbtn.BackgroundImage")));
            this.refreshbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.refreshbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.refreshbtn.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.refreshbtn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.refreshbtn.Location = new System.Drawing.Point(861, 63);
            this.refreshbtn.Name = "refreshbtn";
            this.refreshbtn.Size = new System.Drawing.Size(47, 37);
            this.refreshbtn.TabIndex = 182;
            this.refreshbtn.UseCustomBackColor = true;
            this.refreshbtn.UseCustomForeColor = true;
            this.refreshbtn.UseSelectable = true;
            this.refreshbtn.UseStyleColors = true;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::studentmanagementsystem.Properties.Resources.ssu_school_logo;
            this.pictureBox3.Location = new System.Drawing.Point(23, 25);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(210, 60);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 181;
            this.pictureBox3.TabStop = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(23, 106);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1044, 430);
            this.tabControl1.TabIndex = 183;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Controls.Add(this.Advacne);
            this.tabPage1.Controls.Add(this.txtadvance);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.txtpeegender);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.txtfeestudentclass);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.txtfeestudentsection);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.txtfeestudentname);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.txtfeefathername);
            this.tabPage1.Controls.Add(this.txtfeestudentrollno);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 27);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1036, 399);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Collect Advance Fee";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.metroButton1);
            this.tabPage2.Controls.Add(this.txtcombox);
            this.tabPage2.Controls.Add(this.txtsearch);
            this.tabPage2.Controls.Add(this.btnexport);
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Location = new System.Drawing.Point(4, 27);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1036, 399);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Report Collect Advance Fee";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // Advacne
            // 
            this.Advacne.AutoSize = true;
            this.Advacne.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Advacne.Location = new System.Drawing.Point(21, 205);
            this.Advacne.Name = "Advacne";
            this.Advacne.Size = new System.Drawing.Size(129, 19);
            this.Advacne.TabIndex = 246;
            this.Advacne.Text = "Advacne Fee :";
            // 
            // txtadvance
            // 
            this.txtadvance.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtadvance.Location = new System.Drawing.Point(156, 198);
            this.txtadvance.Name = "txtadvance";
            this.txtadvance.Size = new System.Drawing.Size(199, 29);
            this.txtadvance.TabIndex = 245;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(67, 170);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(83, 19);
            this.label9.TabIndex = 244;
            this.label9.Text = "Gender :";
            // 
            // txtpeegender
            // 
            this.txtpeegender.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpeegender.Location = new System.Drawing.Point(156, 163);
            this.txtpeegender.Name = "txtpeegender";
            this.txtpeegender.Size = new System.Drawing.Size(199, 29);
            this.txtpeegender.TabIndex = 243;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(83, 135);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 19);
            this.label6.TabIndex = 242;
            this.label6.Text = "Class :";
            // 
            // txtfeestudentclass
            // 
            this.txtfeestudentclass.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfeestudentclass.Location = new System.Drawing.Point(156, 128);
            this.txtfeestudentclass.Name = "txtfeestudentclass";
            this.txtfeestudentclass.Size = new System.Drawing.Size(199, 29);
            this.txtfeestudentclass.TabIndex = 241;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(65, 240);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 19);
            this.label5.TabIndex = 240;
            this.label5.Text = "Section :";
            // 
            // txtfeestudentsection
            // 
            this.txtfeestudentsection.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfeestudentsection.Location = new System.Drawing.Point(156, 233);
            this.txtfeestudentsection.Name = "txtfeestudentsection";
            this.txtfeestudentsection.Size = new System.Drawing.Size(199, 29);
            this.txtfeestudentsection.TabIndex = 239;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 19);
            this.label1.TabIndex = 238;
            this.label1.Text = "Student Name :";
            // 
            // txtfeestudentname
            // 
            this.txtfeestudentname.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfeestudentname.Location = new System.Drawing.Point(156, 55);
            this.txtfeestudentname.Name = "txtfeestudentname";
            this.txtfeestudentname.Size = new System.Drawing.Size(199, 29);
            this.txtfeestudentname.TabIndex = 237;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(19, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(131, 19);
            this.label3.TabIndex = 236;
            this.label3.Text = "Father Name :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS Reference Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(68, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 19);
            this.label2.TabIndex = 235;
            this.label2.Text = "Roll No :";
            // 
            // txtfeefathername
            // 
            this.txtfeefathername.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfeefathername.Location = new System.Drawing.Point(156, 93);
            this.txtfeefathername.Name = "txtfeefathername";
            this.txtfeefathername.Size = new System.Drawing.Size(199, 29);
            this.txtfeefathername.TabIndex = 234;
            // 
            // txtfeestudentrollno
            // 
            this.txtfeestudentrollno.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfeestudentrollno.Location = new System.Drawing.Point(156, 17);
            this.txtfeestudentrollno.Name = "txtfeestudentrollno";
            this.txtfeestudentrollno.Size = new System.Drawing.Size(199, 29);
            this.txtfeestudentrollno.TabIndex = 233;
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(597, 9);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(432, 382);
            this.dataGridView1.TabIndex = 232;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = global::studentmanagementsystem.Properties.Resources._13_512;
            this.pictureBox1.Location = new System.Drawing.Point(382, 17);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(162, 147);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 247;
            this.pictureBox1.TabStop = false;
            // 
            // dataGridView2
            // 
            this.dataGridView2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(6, 61);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.Size = new System.Drawing.Size(1024, 332);
            this.dataGridView2.TabIndex = 233;
            // 
            // txtcombox
            // 
            this.txtcombox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtcombox.FontSize = MetroFramework.MetroComboBoxSize.Tall;
            this.txtcombox.FormattingEnabled = true;
            this.txtcombox.ItemHeight = 29;
            this.txtcombox.Items.AddRange(new object[] {
            "NAME",
            "CNIC",
            "PHONE #"});
            this.txtcombox.Location = new System.Drawing.Point(818, 20);
            this.txtcombox.Name = "txtcombox";
            this.txtcombox.Size = new System.Drawing.Size(165, 35);
            this.txtcombox.TabIndex = 236;
            this.txtcombox.UseCustomBackColor = true;
            this.txtcombox.UseCustomForeColor = true;
            this.txtcombox.UseSelectable = true;
            this.txtcombox.UseStyleColors = true;
            // 
            // txtsearch
            // 
            this.txtsearch.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtsearch.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.txtsearch.CustomButton.Image = null;
            this.txtsearch.CustomButton.Location = new System.Drawing.Point(640, 1);
            this.txtsearch.CustomButton.Name = "";
            this.txtsearch.CustomButton.Size = new System.Drawing.Size(33, 33);
            this.txtsearch.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtsearch.CustomButton.TabIndex = 1;
            this.txtsearch.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtsearch.CustomButton.UseSelectable = true;
            this.txtsearch.CustomButton.Visible = false;
            this.txtsearch.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.txtsearch.FontWeight = MetroFramework.MetroTextBoxWeight.Bold;
            this.txtsearch.Lines = new string[0];
            this.txtsearch.Location = new System.Drawing.Point(138, 20);
            this.txtsearch.MaxLength = 32767;
            this.txtsearch.Name = "txtsearch";
            this.txtsearch.PasswordChar = '\0';
            this.txtsearch.PromptText = "Search Bar";
            this.txtsearch.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtsearch.SelectedText = "";
            this.txtsearch.SelectionLength = 0;
            this.txtsearch.SelectionStart = 0;
            this.txtsearch.ShortcutsEnabled = true;
            this.txtsearch.Size = new System.Drawing.Size(674, 35);
            this.txtsearch.TabIndex = 235;
            this.txtsearch.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtsearch.UseCustomBackColor = true;
            this.txtsearch.UseCustomForeColor = true;
            this.txtsearch.UseSelectable = true;
            this.txtsearch.UseStyleColors = true;
            this.txtsearch.WaterMark = "Search Bar";
            this.txtsearch.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtsearch.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // btnexport
            // 
            this.btnexport.BackColor = System.Drawing.Color.Teal;
            this.btnexport.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnexport.Location = new System.Drawing.Point(-301, 20);
            this.btnexport.Name = "btnexport";
            this.btnexport.Size = new System.Drawing.Size(92, 35);
            this.btnexport.TabIndex = 234;
            this.btnexport.Text = "Export Report";
            this.btnexport.UseCustomBackColor = true;
            this.btnexport.UseCustomForeColor = true;
            this.btnexport.UseMnemonic = false;
            this.btnexport.UseSelectable = true;
            this.btnexport.UseStyleColors = true;
            // 
            // metroButton1
            // 
            this.metroButton1.BackColor = System.Drawing.Color.Teal;
            this.metroButton1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.metroButton1.Location = new System.Drawing.Point(40, 20);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(92, 35);
            this.metroButton1.TabIndex = 237;
            this.metroButton1.Text = "Export Report";
            this.metroButton1.UseCustomBackColor = true;
            this.metroButton1.UseCustomForeColor = true;
            this.metroButton1.UseMnemonic = false;
            this.metroButton1.UseSelectable = true;
            this.metroButton1.UseStyleColors = true;
            // 
            // collect_advancefee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1090, 559);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.refreshbtn);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Name = "collect_advancefee";
            this.Text = "collect_advancefee";
            this.Load += new System.EventHandler(this.collect_advancefee_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroButton refreshbtn;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label Advacne;
        private System.Windows.Forms.TextBox txtadvance;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtpeegender;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtfeestudentclass;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtfeestudentsection;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtfeestudentname;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtfeefathername;
        private System.Windows.Forms.TextBox txtfeestudentrollno;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private MetroFramework.Controls.MetroComboBox txtcombox;
        private MetroFramework.Controls.MetroTextBox txtsearch;
        private MetroFramework.Controls.MetroButton btnexport;
        private MetroFramework.Controls.MetroButton metroButton1;
    }
}