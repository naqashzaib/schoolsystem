﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace studentmanagementsystem
{
    public partial class collect_advancefee : MetroFramework.Forms.MetroForm
    {
        public collect_advancefee()
        {
            InitializeComponent();
        }

        private void collect_advancefee_Load(object sender, EventArgs e)
        {

        }
    }
}
