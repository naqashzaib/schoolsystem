﻿namespace studentmanagementsystem
{
    partial class Fine_report
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Fine_report));
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtunpaidsection = new System.Windows.Forms.ComboBox();
            this.txtunpaidclass = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.metroButton2 = new MetroFramework.Controls.MetroButton();
            this.metroButton3 = new MetroFramework.Controls.MetroButton();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.refreshbtn = new MetroFramework.Controls.MetroButton();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.btnupaidexportreport = new MetroFramework.Controls.MetroButton();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnupaidsaveall = new MetroFramework.Controls.MetroButton();
            this.dateunpaidfrom = new System.Windows.Forms.DateTimePicker();
            this.dateunpaidto = new System.Windows.Forms.DateTimePicker();
            this.label34 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.btnupaidsearch = new MetroFramework.Controls.MetroButton();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroButton1
            // 
            this.metroButton1.BackColor = System.Drawing.Color.CadetBlue;
            this.metroButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroButton1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.metroButton1.Location = new System.Drawing.Point(148, 169);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(125, 35);
            this.metroButton1.TabIndex = 245;
            this.metroButton1.Text = "Search";
            this.metroButton1.UseCustomBackColor = true;
            this.metroButton1.UseCustomForeColor = true;
            this.metroButton1.UseMnemonic = false;
            this.metroButton1.UseSelectable = true;
            this.metroButton1.UseStyleColors = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(4, 128);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 20);
            this.label1.TabIndex = 244;
            this.label1.Text = "Section :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.Location = new System.Drawing.Point(21, 90);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 20);
            this.label4.TabIndex = 243;
            this.label4.Text = "Class :";
            // 
            // txtunpaidsection
            // 
            this.txtunpaidsection.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtunpaidsection.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtunpaidsection.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtunpaidsection.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtunpaidsection.FormattingEnabled = true;
            this.txtunpaidsection.Location = new System.Drawing.Point(93, 124);
            this.txtunpaidsection.Name = "txtunpaidsection";
            this.txtunpaidsection.Size = new System.Drawing.Size(164, 28);
            this.txtunpaidsection.TabIndex = 242;
            this.txtunpaidsection.Text = "----Select Section----";
            // 
            // txtunpaidclass
            // 
            this.txtunpaidclass.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtunpaidclass.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtunpaidclass.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtunpaidclass.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtunpaidclass.FormattingEnabled = true;
            this.txtunpaidclass.Location = new System.Drawing.Point(93, 87);
            this.txtunpaidclass.Name = "txtunpaidclass";
            this.txtunpaidclass.Size = new System.Drawing.Size(164, 28);
            this.txtunpaidclass.TabIndex = 241;
            this.txtunpaidclass.Text = "------Select Class-----";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(24, 21);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 20);
            this.label6.TabIndex = 239;
            this.label6.Text = "From :";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarTitleBackColor = System.Drawing.SystemColors.ControlText;
            this.dateTimePicker1.CalendarTitleForeColor = System.Drawing.SystemColors.HotTrack;
            this.dateTimePicker1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dateTimePicker1.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(111, 47);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(146, 26);
            this.dateTimePicker1.TabIndex = 238;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CalendarTitleBackColor = System.Drawing.SystemColors.ControlText;
            this.dateTimePicker2.CalendarTitleForeColor = System.Drawing.SystemColors.HotTrack;
            this.dateTimePicker2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dateTimePicker2.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2.Location = new System.Drawing.Point(111, 15);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(146, 26);
            this.dateTimePicker2.TabIndex = 237;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(45, 47);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 20);
            this.label5.TabIndex = 240;
            this.label5.Text = "To :";
            // 
            // metroButton2
            // 
            this.metroButton2.BackColor = System.Drawing.Color.DodgerBlue;
            this.metroButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroButton2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.metroButton2.Location = new System.Drawing.Point(6, 210);
            this.metroButton2.Name = "metroButton2";
            this.metroButton2.Size = new System.Drawing.Size(122, 35);
            this.metroButton2.TabIndex = 236;
            this.metroButton2.Text = "Add To Unpaid ";
            this.metroButton2.UseCustomBackColor = true;
            this.metroButton2.UseCustomForeColor = true;
            this.metroButton2.UseMnemonic = false;
            this.metroButton2.UseSelectable = true;
            this.metroButton2.UseStyleColors = true;
            // 
            // metroButton3
            // 
            this.metroButton3.BackColor = System.Drawing.Color.Teal;
            this.metroButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroButton3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.metroButton3.Location = new System.Drawing.Point(6, 169);
            this.metroButton3.Name = "metroButton3";
            this.metroButton3.Size = new System.Drawing.Size(122, 35);
            this.metroButton3.TabIndex = 234;
            this.metroButton3.Text = "Export Report";
            this.metroButton3.UseCustomBackColor = true;
            this.metroButton3.UseCustomForeColor = true;
            this.metroButton3.UseMnemonic = false;
            this.metroButton3.UseSelectable = true;
            this.metroButton3.UseStyleColors = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(289, 6);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.Size = new System.Drawing.Size(1010, 440);
            this.dataGridView2.TabIndex = 235;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(19, 114);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1313, 482);
            this.tabControl1.TabIndex = 187;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.metroButton1);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.txtunpaidsection);
            this.tabPage2.Controls.Add(this.txtunpaidclass);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.dateTimePicker1);
            this.tabPage2.Controls.Add(this.dateTimePicker2);
            this.tabPage2.Controls.Add(this.metroButton2);
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Controls.Add(this.metroButton3);
            this.tabPage2.Location = new System.Drawing.Point(4, 27);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1305, 451);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Search Fine Report Class With Section";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // refreshbtn
            // 
            this.refreshbtn.BackColor = System.Drawing.Color.Transparent;
            this.refreshbtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("refreshbtn.BackgroundImage")));
            this.refreshbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.refreshbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.refreshbtn.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.refreshbtn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.refreshbtn.Location = new System.Drawing.Point(1276, 71);
            this.refreshbtn.Name = "refreshbtn";
            this.refreshbtn.Size = new System.Drawing.Size(47, 37);
            this.refreshbtn.TabIndex = 186;
            this.refreshbtn.UseCustomBackColor = true;
            this.refreshbtn.UseCustomForeColor = true;
            this.refreshbtn.UseSelectable = true;
            this.refreshbtn.UseStyleColors = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("DS-Digital", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Crimson;
            this.label16.Location = new System.Drawing.Point(1135, 44);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(124, 31);
            this.label16.TabIndex = 184;
            this.label16.Text = "00:00:00";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Forte", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.SlateGray;
            this.label15.Location = new System.Drawing.Point(518, 44);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(262, 41);
            this.label15.TabIndex = 183;
            this.label15.Text = "FINE-REPORT";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::studentmanagementsystem.Properties.Resources.ssu_school_logo;
            this.pictureBox3.Location = new System.Drawing.Point(19, 25);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(210, 60);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 185;
            this.pictureBox3.TabStop = false;
            // 
            // btnupaidexportreport
            // 
            this.btnupaidexportreport.BackColor = System.Drawing.Color.Teal;
            this.btnupaidexportreport.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnupaidexportreport.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnupaidexportreport.Location = new System.Drawing.Point(23, 107);
            this.btnupaidexportreport.Name = "btnupaidexportreport";
            this.btnupaidexportreport.Size = new System.Drawing.Size(125, 35);
            this.btnupaidexportreport.TabIndex = 222;
            this.btnupaidexportreport.Text = "Export Report";
            this.btnupaidexportreport.UseCustomBackColor = true;
            this.btnupaidexportreport.UseCustomForeColor = true;
            this.btnupaidexportreport.UseMnemonic = false;
            this.btnupaidexportreport.UseSelectable = true;
            this.btnupaidexportreport.UseStyleColors = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(285, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1014, 441);
            this.dataGridView1.TabIndex = 223;
            // 
            // btnupaidsaveall
            // 
            this.btnupaidsaveall.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnupaidsaveall.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnupaidsaveall.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnupaidsaveall.Location = new System.Drawing.Point(23, 148);
            this.btnupaidsaveall.Name = "btnupaidsaveall";
            this.btnupaidsaveall.Size = new System.Drawing.Size(125, 35);
            this.btnupaidsaveall.TabIndex = 224;
            this.btnupaidsaveall.Text = "Add To Unpaid ";
            this.btnupaidsaveall.UseCustomBackColor = true;
            this.btnupaidsaveall.UseCustomForeColor = true;
            this.btnupaidsaveall.UseMnemonic = false;
            this.btnupaidsaveall.UseSelectable = true;
            this.btnupaidsaveall.UseStyleColors = true;
            // 
            // dateunpaidfrom
            // 
            this.dateunpaidfrom.CalendarTitleBackColor = System.Drawing.SystemColors.ControlText;
            this.dateunpaidfrom.CalendarTitleForeColor = System.Drawing.SystemColors.HotTrack;
            this.dateunpaidfrom.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dateunpaidfrom.CustomFormat = "yyyy-MM-dd";
            this.dateunpaidfrom.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateunpaidfrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateunpaidfrom.Location = new System.Drawing.Point(100, 35);
            this.dateunpaidfrom.Name = "dateunpaidfrom";
            this.dateunpaidfrom.Size = new System.Drawing.Size(146, 26);
            this.dateunpaidfrom.TabIndex = 225;
            // 
            // dateunpaidto
            // 
            this.dateunpaidto.CalendarTitleBackColor = System.Drawing.SystemColors.ControlText;
            this.dateunpaidto.CalendarTitleForeColor = System.Drawing.SystemColors.HotTrack;
            this.dateunpaidto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dateunpaidto.CustomFormat = "yyyy-MM-dd";
            this.dateunpaidto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateunpaidto.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateunpaidto.Location = new System.Drawing.Point(100, 66);
            this.dateunpaidto.Name = "dateunpaidto";
            this.dateunpaidto.Size = new System.Drawing.Size(146, 26);
            this.dateunpaidto.TabIndex = 226;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.Red;
            this.label34.Location = new System.Drawing.Point(34, 41);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(0, 20);
            this.label34.TabIndex = 227;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.Red;
            this.label26.Location = new System.Drawing.Point(55, 67);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(0, 20);
            this.label26.TabIndex = 228;
            // 
            // btnupaidsearch
            // 
            this.btnupaidsearch.BackColor = System.Drawing.Color.CadetBlue;
            this.btnupaidsearch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnupaidsearch.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnupaidsearch.Location = new System.Drawing.Point(154, 107);
            this.btnupaidsearch.Name = "btnupaidsearch";
            this.btnupaidsearch.Size = new System.Drawing.Size(125, 35);
            this.btnupaidsearch.TabIndex = 233;
            this.btnupaidsearch.Text = "Search";
            this.btnupaidsearch.UseCustomBackColor = true;
            this.btnupaidsearch.UseCustomForeColor = true;
            this.btnupaidsearch.UseMnemonic = false;
            this.btnupaidsearch.UseSelectable = true;
            this.btnupaidsearch.UseStyleColors = true;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnupaidsearch);
            this.tabPage1.Controls.Add(this.label26);
            this.tabPage1.Controls.Add(this.label34);
            this.tabPage1.Controls.Add(this.dateunpaidto);
            this.tabPage1.Controls.Add(this.dateunpaidfrom);
            this.tabPage1.Controls.Add(this.btnupaidsaveall);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.btnupaidexportreport);
            this.tabPage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 27);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1305, 451);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Search Student Fine Report";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // Fine_report
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1350, 620);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.refreshbtn);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.pictureBox3);
            this.Name = "Fine_report";
            this.Text = "unpaid_fee_report";
            this.Load += new System.EventHandler(this.unpaid_fee_report_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroButton metroButton1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox txtunpaidsection;
        private System.Windows.Forms.ComboBox txtunpaidclass;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label5;
        private MetroFramework.Controls.MetroButton metroButton2;
        private MetroFramework.Controls.MetroButton metroButton3;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private MetroFramework.Controls.MetroButton refreshbtn;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TabPage tabPage1;
        private MetroFramework.Controls.MetroButton btnupaidsearch;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.DateTimePicker dateunpaidto;
        private System.Windows.Forms.DateTimePicker dateunpaidfrom;
        private MetroFramework.Controls.MetroButton btnupaidsaveall;
        private System.Windows.Forms.DataGridView dataGridView1;
        private MetroFramework.Controls.MetroButton btnupaidexportreport;
    }
}